
copyright (c) DheerajKumar 2025

What version, confused?
CEG-v1 : A complete sleek UI based Entropy Generator.(Can only run on windows system,.)
DEG-v1 : Python-Terminal Based version. Both source code and windows executable files are there.
DEG-Cv1: C-Language - terminal based Entropy Generator. Both Source Code and windows exe available. 

GitHub:
https://github.com/ProCoder1199X/ChaoticEntropy

Author: 
DheerajKumar (ProCoder1199X)
website: https://procoder1199x.github.io
GitHub : https://github.com/ProCoder1199X