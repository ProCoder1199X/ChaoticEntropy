🔐 ChaoticEntropy Generator (CEG)

**Chaotic Entropy Generator** is a **User-Interface based** entropy string generator based on user input, complex math transformations, and real-world weather data. This tool turns a 1–22 digit number into a 64-character entropy hash using chaotic but deterministic algorithms.

---

## 🚀 Features (v1.0)

- 📌 Input up to 22-digit numeric seeds
- 🌍 Converts seed into pseudo-random latitude & longitude
- 📅 Fetches temperature from that location from a past random day (1–30 days ago)
- 🧠 Generates a 64-character entropy hash using SHA-512
- ❄️ Dark themed professional UI using `customtkinter`
- 🔁 Fallback algorithm for synthetic temperature if no weather data available
- ⚡ Packaged as `.exe` for easy double-click launch on Windows (no terminal needed)

developed by: 
DheerajKumar
GitHub: https://github.com/ProCoder199X
website: https://procoder1199x.github.io