🛠 C Version: `Chaotic Entropy`. Version-2 
- Fully offline, terminal-based entropy generator
- Uses:
  - Manual temperature input
  - Manual human-random input
- Applies **non-linear transformations** (sine, square roots, etc.)
- Generates and prints:
  - Random coordinates
  - Final entropic number (within 0–99999)