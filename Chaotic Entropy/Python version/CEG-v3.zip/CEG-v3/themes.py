# === themes.py ===

import customtkinter as ctk

widget_registry = []

themes = {
    "Ocean": {"bg": "#1B262C", "fg": "#BBE1FA"},
    "Sunset": {"bg": "#2C061F", "fg": "#FF6B6B"},
    "Cyberpunk": {"bg": "#0F0F0F", "fg": "#00FFE0"},
    "Hacker": {"bg": "#000000", "fg": "#00FF00"},
    "Solarized": {"bg": "#002B36", "fg": "#93A1A1"},
    "Dracula": {"bg": "#282A36", "fg": "#F8F8F2"},
    "Forest": {"bg": "#013220", "fg": "#A8E6CF"},
    "Classic": {"bg": "#F0F0F0", "fg": "#222222"},
}

def register_widget(widget):
    if widget not in widget_registry:
        widget_registry.append(widget)

def apply_theme(theme_name):
    theme = themes.get(theme_name)
    if not theme:
        return

    for widget in widget_registry:
        if isinstance(widget, (ctk.CTkLabel, ctk.CTkButton, ctk.CTkEntry, ctk.CTkTextbox, ctk.CTkOptionMenu)):
            widget.configure(fg_color=theme["bg"], text_color=theme["fg"])
