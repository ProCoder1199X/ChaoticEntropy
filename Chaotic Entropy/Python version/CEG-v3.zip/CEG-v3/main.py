# === main.py ===
import customtkinter as ctk
from ui import EntropyUI

import sys
import os

def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller .exe"""
    try:
        base_path = sys._MEIPASS  # PyInstaller temp dir
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)


ctk.set_appearance_mode("dark")  # default mode
ctk.set_default_color_theme("blue")  # can be changed dynamically

if __name__ == "__main__":
    try:
        app = EntropyUI()
        app.mainloop()
    except Exception as e:
        print(f"Error starting application: {e}")
