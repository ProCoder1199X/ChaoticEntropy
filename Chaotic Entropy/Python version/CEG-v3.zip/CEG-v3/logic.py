import hashlib
import math
import random
import platform
from datetime import datetime, timedelta

def complex_transform(seed_str):
    """
    Transforms a seed string into latitude and longitude values.
    Returns (latitude, longitude) or (None, None) if invalid.
    """
    try:
        seed = int(seed_str)
    except ValueError:
        return None, None

    s1 = math.sin(seed * math.pi)
    s2 = math.cos(seed % 9973)
    s3 = math.log(abs(seed) + 1)
    s4 = math.tan(seed % 10007)
    s5 = math.sqrt(abs(seed % 100000) + 1)
    combined = (s1 * s2 * s3 * s4 * s5 * 1e6) + random.random()

    latitude = (combined % 180) - 90
    longitude = (combined % 360) - 180
    return round(latitude, 6), round(longitude, 6)

def generate_random_days_offset(seed_str):
    """
    Generates a random offset in days based on the seed string.
    """
    h = hashlib.sha256(seed_str.encode()).hexdigest()
    rand_int = int(h[:8], 16)
    return rand_int % 30 + 1

def fetch_temperature(lat, lon, days_ago, source="open-meteo"):
    """
    Fetches temperature data from the specified source.
    Returns average temperature or None if unavailable.
    """
    try:
        from datetime import datetime
        import requests
    except ImportError:
        return None

    if source == "disabled":
        return None

    date = datetime.utcnow() - timedelta(days=days_ago)
    url = (
        f"https://api.open-meteo.com/v1/forecast?"
        f"latitude={lat}&longitude={lon}&hourly=temperature_2m"
        f"&start={date.strftime('%Y-%m-%d')}T00:00:00Z"
        f"&end={date.strftime('%Y-%m-%d')}T23:59:59Z"
    )

    try:
        r = requests.get(url, timeout=5)
        r.raise_for_status()
        data = r.json()
        temp_data = data.get("hourly", {}).get("temperature_2m", [])
        if temp_data:
            return round(sum(temp_data) / len(temp_data), 2)
    except Exception:
        pass

    return None

def generate_offline_temp(seed_str):
    """
    Generates a pseudo-random temperature for offline mode.
    """
    try:
        base = int(seed_str)
        mix = abs(math.sin(base % 99991) * math.cos(base % 12347) * 999)
        return round((mix % 45) + 10, 2)
    except Exception:
        return 27.0

def extra_entropy(seed_str, lat, lon, temp, selected_date):
    """
    Adds extra entropy using system info, time, and seed hash mixing.
    """
    sys_info = platform.platform()
    now = datetime.utcnow().isoformat()
    date_str = selected_date if selected_date else now
    base = f"{seed_str}-{lat}-{lon}-{temp}-{sys_info}-{date_str}-{random.random()}"
    h = hashlib.sha3_512(base.encode()).hexdigest()
    return h

def final_entropy(seed_str, lat, lon, temp, selected_date, digits=64):
    """
    Generates the final entropy string using multiple sources.
    """
    base = f"{seed_str}-{lat}-{lon}-{temp}-{selected_date}"
    h1 = hashlib.sha512(base.encode()).hexdigest()
    h2 = extra_entropy(seed_str, lat, lon, temp, selected_date)
    combined = hashlib.sha3_512((h1 + h2).encode()).hexdigest()

    if digits == 1:
        return str(int(combined, 16) % 10)
    elif digits == 2:
        return str(int(combined, 16) % 100).zfill(2)
    elif digits <= 12:
        return str(int(combined, 16) % (10 ** digits)).zfill(digits)
    else:
        return combined[:digits]

def entropy_strength(entropy_str):
    """
    Returns a string representing the strength of the entropy.
    """
    length = len(entropy_str)
    if length <= 2:
        return "Weak"
    elif length <= 8:
        return "Moderate"
    elif length <= 32:
        return "Strong"
    else:
        return "Very Strong"

def generate_shower_value(entropy_str):
    """
    Generates a 'shower' value from the entropy string.
    """
    try:
        return int(entropy_str[:3], 16) % 100
    except Exception:
        return random.randint(0, 99)

def generate_entropy_bundle(seed_str, selected_date, use_offline_mode, weather_source, digits=64):
    """
    Generates a bundle of entropy-related values.
    """
    lat, lon = complex_transform(seed_str)
    if lat is None or lon is None:
        return None

    if use_offline_mode:
        temp = generate_offline_temp(seed_str)
    else:
        days_offset = generate_random_days_offset(seed_str)
        temp = fetch_temperature(lat, lon, days_offset, weather_source)
        if temp is None:
            temp = generate_offline_temp(seed_str)

    entropy = final_entropy(seed_str, lat, lon, temp, selected_date, digits)
    strength = entropy_strength(entropy)
    shower_val = generate_shower_value(entropy)

    return {
        "lat": lat,
        "lon": lon,
        "temp": temp,
        "entropy": entropy,
        "strength": strength,
        "shower": shower_val
    }
