# === ui.py ===
import customtkinter as ctk
from logic import generate_entropy_bundle
from themes import apply_theme, themes, register_widget
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk, ImageSequence
import threading
import time
import os
import sys

def resource_path(relative_path):
    """Get absolute path to resource, works for dev and for PyInstaller .exe"""
    try:
        base_path = sys._MEIPASS  # PyInstaller temp dir
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

class EntropyUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("ChaoticEntropy Generator v3")
        self.geometry("850x650")
        self.resizable(False, False)

        self.seed_history = []
        self.dark_mode = True
        self.animation_thread_started = False

        # Set window icon
        try:
            self.tk.call('wm', 'iconphoto', self._w, tk.PhotoImage(file=resource_path('assets/icons/app_icon.png')))
        except Exception:
            pass

        # Theme Setup
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.create_widgets()

        # Load GIF frames once
        try:
            gif_path = resource_path("assets/icons/Entropy.gif")
            gif = Image.open(gif_path)
            self.gif_frames = [ctk.CTkImage(img.copy().resize((150, 150))) for img in ImageSequence.Iterator(gif)]
        except Exception:
            self.gif_frames = []

    def create_widgets(self):
        # Label
        self.entry_label = ctk.CTkLabel(self, text="Enter Seed (1-22 digits):")
        self.entry_label.pack(pady=10)
        register_widget(self.entry_label)

        # Seed Input
        self.seed_input = ctk.CTkEntry(self, width=350)
        self.seed_input.pack(pady=5)
        register_widget(self.seed_input)

        # Theme Menu
        self.theme_menu = ctk.CTkOptionMenu(self, values=list(themes.keys()), command=self.switch_theme)
        self.theme_menu.pack(pady=10)
        register_widget(self.theme_menu)

        # Date Picker
        self.date_picker = ctk.CTkEntry(self, placeholder_text="YYYY-MM-DD (optional)", width=200)
        self.date_picker.pack(pady=5)
        register_widget(self.date_picker)

        # Entropy Length
        self.length_label = ctk.CTkLabel(self, text="Entropy Length (1-128):")
        self.length_label.pack(pady=5)
        register_widget(self.length_label)
        self.length_input = ctk.CTkEntry(self, width=100)
        self.length_input.insert(0, "64")
        self.length_input.pack(pady=5)
        register_widget(self.length_input)

        # Offline Mode Checkbox
        self.offline_var = tk.BooleanVar()
        self.offline_checkbox = ctk.CTkCheckBox(self, text="Offline Mode", variable=self.offline_var)
        self.offline_checkbox.pack(pady=5)
        register_widget(self.offline_checkbox)

        # Generate Button
        self.generate_button = ctk.CTkButton(self, text="Generate Entropy", command=self.generate)
        self.generate_button.pack(pady=10)
        register_widget(self.generate_button)

        # Entropy Output Box
        self.entropy_box = ctk.CTkTextbox(self, height=200, width=700)
        self.entropy_box.pack(pady=10)
        self.entropy_box.insert("0.0", "Entropy output will appear here...")
        register_widget(self.entropy_box)

        # Copy Button
        try:
            copy_icon = ctk.CTkImage(Image.open(resource_path("assets/icons/copy.png")), size=(20, 20))
        except Exception:
            copy_icon = None
        self.copy_button = ctk.CTkButton(self, text=" Copy", image=copy_icon, compound="left", command=self.copy_clipboard)
        self.copy_button.pack(pady=5)
        register_widget(self.copy_button)

        # Save Button
        try:
            save_icon = ctk.CTkImage(Image.open(resource_path("assets/icons/save.png")), size=(20, 20))
        except Exception:
            save_icon = None
        self.save_button = ctk.CTkButton(self, text=" Save", image=save_icon, compound="left", command=self.save_result)
        self.save_button.pack(pady=5)
        register_widget(self.save_button)

        # Toggle Mode Button
        self.toggle_mode_button = ctk.CTkButton(self, text="Toggle Dark/Light Mode", command=self.toggle_mode)
        self.toggle_mode_button.pack(pady=10)
        register_widget(self.toggle_mode_button)

        # Info Label
        self.info_label = ctk.CTkLabel(self, text="ChaoticEntropy by DheerajKumar.N")
        self.info_label.pack(pady=10)
        register_widget(self.info_label)

        # Animation Label (empty initially)
        self.animation_label = ctk.CTkLabel(self, text="")
        self.animation_label.pack(pady=5)
        register_widget(self.animation_label)

    def animate_entropy(self):
        if self.animation_thread_started or not self.gif_frames:
            return  # Avoid starting multiple threads

        def loop():
            self.animation_thread_started = True
            frame = 0
            while True:
                self.animation_label.configure(image=self.gif_frames[frame])
                frame = (frame + 1) % len(self.gif_frames)
                time.sleep(0.1)

        threading.Thread(target=loop, daemon=True).start()

    def validate_seed(self, seed):
        return seed.isdigit() and 1 <= len(seed) <= 22

    def validate_length(self, length):
        try:
            val = int(length)
            return 1 <= val <= 128
        except Exception:
            return False

    def generate(self):
        seed = self.seed_input.get().strip()
        custom_date = self.date_picker.get().strip()
        length = self.length_input.get().strip()
        use_offline = self.offline_var.get()

        if not self.validate_seed(seed):
            self.entropy_box.delete("0.0", "end")
            self.entropy_box.insert("0.0", "Invalid Seed. Please enter 1-22 digits.")
            return

        if not self.validate_length(length):
            self.entropy_box.delete("0.0", "end")
            self.entropy_box.insert("0.0", "Invalid entropy length. Enter a number between 1 and 128.")
            return

        digits = int(length)
        bundle = generate_entropy_bundle(seed, custom_date, use_offline_mode=use_offline, weather_source="open-meteo", digits=digits)

        if not bundle:
            self.entropy_box.delete("0.0", "end")
            self.entropy_box.insert("0.0", "Invalid Seed or error in generation. Please try again.")
            return

        output = (
            f"Entropy: {bundle['entropy']}\n"
            f"Strength: {bundle['strength']}\n"
            f"Shower Value: {bundle['shower']}\n"
            f"Latitude: {bundle['lat']}\n"
            f"Longitude: {bundle['lon']}\n"
            f"Temperature: {bundle['temp']}\n"
        )
        self.entropy_box.delete("0.0", "end")
        self.entropy_box.insert("0.0", output)
        self.seed_history.append(seed)

        self.animate_entropy()

    def copy_clipboard(self):
        self.clipboard_clear()
        self.clipboard_append(self.entropy_box.get("0.0", "end"))
        self.update()

    def save_result(self):
        result = self.entropy_box.get("0.0", "end")
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text Files", "*.txt")])
        if file_path:
            try:
                with open(file_path, "w") as f:
                    f.write(result)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save file: {e}")

    def toggle_mode(self):
        self.dark_mode = not self.dark_mode
        mode = "dark" if self.dark_mode else "light"
        ctk.set_appearance_mode(mode)

    def switch_theme(self, theme_name):
        apply_theme(theme_name)
